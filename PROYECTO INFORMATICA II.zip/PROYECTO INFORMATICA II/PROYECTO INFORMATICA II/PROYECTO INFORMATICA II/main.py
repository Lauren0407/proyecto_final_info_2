from mi_controlador import Controlador

if __name__ == "__main__":
    controlador = Controlador()
    controlador.login()
